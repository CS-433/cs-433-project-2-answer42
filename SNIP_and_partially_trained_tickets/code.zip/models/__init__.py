from .resnet import resnet32, ResNet
from .vgg import vgg19, VGG